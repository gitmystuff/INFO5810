# neo4j-demos

Small, self-contained demos of Graph RAG (Retrieval-Augmented Generation grounded
in a knowledge graph), built for INFO 5810 — Data Analysis and Knowledge Discovery.

## What's here

**`graph_rag.py`** — connects to a local Neo4j database, retrieves facts relevant
to a question by searching the graph, and asks a language model (Groq's
`openai/gpt-oss-120b`) to answer using only those retrieved facts. Compares that
grounded answer against what the same model says with no retrieval at all.

**`create_graph.cypher`** — the small knowledge graph this demo runs against: a
handful of facts about two people, Bob and Alice, and the Mona Lisa, including
a few specific, made-up details (a company name, a job title, a dollar figure)
that no language model could know from training. That's deliberate — if the
grounded answer is correct, it's proof the retrieval step actually worked,
not a lucky guess from the model's training data.

## Setup

1. **Install [uv](https://docs.astral.sh/uv/)**, if you don't have it already.
2. **Install and start Neo4j locally.** See the
   [Neo4j Windows installation guide](https://neo4j.com/docs/operations-manual/current/installation/windows/)
   (or the equivalent for your OS). Start it with:
   ```
   neo4j console
   ```
3. **Load the graph.** Open Neo4j Browser at <http://localhost:7474/browser/>,
   paste in the contents of `create_graph.cypher`, and run it.
4. **Get a free Groq API key** at [console.groq.com](https://console.groq.com).
5. **Set up your environment file:**
   ```
   cp .env.example .env
   ```
   Then edit `.env` and fill in your real Neo4j password and Groq API key.
6. **Install dependencies:**
   ```
   uv sync
   ```

## Run

```
uv run graph_rag.py
```

This prints three things: an ungrounded answer (no facts retrieved), the facts
actually pulled from the graph, and a grounded answer using only those facts.

## A note on the data

`create_graph.cypher` uses a generic `:Entity` label for every node, rather
than specific labels like `:Person` or `:Company`. This keeps it safe to load
into a Neo4j instance that already has other data in it (for example, the
official [Neo4j Movie Graph tutorial](https://neo4j.com/docs/getting-started/current/appendix/tutorials/guide-cypher-basics/)),
since `:Entity` won't collide with labels used elsewhere.

## License

MIT — use this however is useful to you.
