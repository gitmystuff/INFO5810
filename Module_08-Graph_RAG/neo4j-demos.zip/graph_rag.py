"""
Graph RAG, running entirely locally: Neo4j on your own machine, a Groq model call,
no Colab, no notebook. Same mechanism as the Colab version -- retrieve facts from
a graph, then ground the model's answer in exactly those facts -- just run as a
plain Python script from a VS Code terminal.

Setup, once:
    1. Copy .env.example to .env in this same folder, and fill in your real
       Neo4j password and Groq API key.
    2. Make sure your local Neo4j database is running (neo4j console) and that
       the Bob/Alice/Mona Lisa graph has already been loaded (see create_graph.cypher).
    3. From this project's root folder: uv sync

Run:
    uv run graph_rag.py
"""

import os
import time
from dotenv import load_dotenv
from neo4j import GraphDatabase
import groq

load_dotenv()  # reads the .env file in this folder into environment variables

REQUIRED = ["NEO4J_URI", "NEO4J_USER", "NEO4J_PASSWORD"]
missing = [name for name in REQUIRED if not os.environ.get(name)]
if missing:
    raise SystemExit(
        f"Missing required setting(s) in .env: {', '.join(missing)}\n"
        f"Copy .env.example to .env in this folder and fill in your real values."
    )

NEO4J_URI = os.environ["NEO4J_URI"]
NEO4J_USER = os.environ["NEO4J_USER"]
NEO4J_PASSWORD = os.environ["NEO4J_PASSWORD"]
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")  # optional -- falls back gracefully if missing
MODEL = "openai/gpt-oss-120b"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
groq_client = groq.Groq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None


# ---------------------------------------------------------------- retrieval

def get_all_entity_names(driver):
    # One query, run once: every entity name currently in the graph.
    # Cheap to cache, since this graph is small and rarely changes mid-demo.
    with driver.session() as session:
        result = session.run("MATCH (e:Entity) RETURN e.name AS name")
        return [record["name"] for record in result]


def find_mentioned_entities(question, all_names):
    question_lower = question.lower()
    return [name for name in all_names if name.lower() in question_lower]


def retrieve_facts(question, driver, all_names):
    entities = find_mentioned_entities(question, all_names)
    facts = set()
    cypher = """
        MATCH (e:Entity {name: $entity_name})-[r]-(other:Entity)
        RETURN
          CASE WHEN startNode(r) = e THEN e.name ELSE other.name END AS subject,
          type(r) AS predicate,
          CASE WHEN startNode(r) = e THEN other.name ELSE e.name END AS object
    """
    with driver.session() as session:
        for entity_name in entities:
            result = session.run(cypher, entity_name=entity_name)
            for record in result:
                facts.add((record["subject"], record["predicate"], record["object"]))
    return entities, facts


# ------------------------------------------------------------- grounding

def build_grounded_prompt(question, facts):
    facts_text = "\n".join(f"- {s} {p} {o}" for s, p, o in facts)
    system_message = (
        "You are a careful assistant. Answer the user's question using ONLY the facts "
        "listed below. If the facts do not contain the answer, say you don't have that "
        "information -- do not guess or use outside knowledge.\n\n"
        f"FACTS:\n{facts_text}"
    )
    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": question},
    ]


def ask_model(messages, model=MODEL):
    if not groq_client:
        return "[OFFLINE FALLBACK -- no GROQ_API_KEY found in .env. Add your key to see the real model's answer.]"
    try:
        # reasoning_effort="low" keeps responses fast for this simple fact-lookup task.
        # gpt-oss-120b supports "none"/"low"/"medium"/"high"; left unset, it defaults to
        # doing more multi-step thinking before answering, which is slower and unnecessary
        # here -- the model only needs to read a short fact list and answer directly.
        resp = groq_client.chat.completions.create(
            model=model, messages=messages, temperature=0.2, reasoning_effort="low"
        )
        return resp.choices[0].message.content
    except groq.GroqError as e:
        return f"[Groq API error: {e}]"


# -------------------------------------------------------------------- demo

def timed(label, fn, *args):
    # Runs fn(*args), prints how long it took, and returns fn's result -- so we
    # can see exactly which step is slow instead of guessing.
    start = time.perf_counter()
    result = fn(*args)
    elapsed = time.perf_counter() - start
    print(f"[{elapsed:6.2f}s] {label}")
    return result


def main():
    all_names = timed("Load entity names from Neo4j", get_all_entity_names, driver)
    print(f"Loaded {len(all_names)} entities from the local Neo4j graph.")

    question = "What company does Bob work at?"
    print(f"\nQuestion: {question}")

    print("\n" + "=" * 60)
    print("STEP 1 -- UNGROUNDED (no retrieval, model answers from memory alone):")
    print("=" * 60)
    ungrounded = timed("Groq call (ungrounded)", ask_model, [{"role": "user", "content": question}])
    print(ungrounded)

    print("\n" + "=" * 60)
    print("STEP 2 -- RETRIEVAL (searching the Neo4j graph for relevant facts):")
    print("=" * 60)
    entities, facts = timed("Neo4j retrieval query", retrieve_facts, question, driver, all_names)
    print(f"Entities found in the question: {entities}")
    print(f"Facts retrieved ({len(facts)}):")
    for f in sorted(facts):
        print("  ", f)

    print("\n" + "=" * 60)
    print("STEP 3 -- GROUNDED (model answers using only the retrieved facts):")
    print("=" * 60)
    grounded = timed("Groq call (grounded)", ask_model, build_grounded_prompt(question, facts))
    print(grounded)

    driver.close()


if __name__ == "__main__":
    main()
